import { parseExcel } from './trainingParser.js';
import { db, ref, set } from './firebase.js';

document.getElementById('uploadExcel').addEventListener('change', (event) => {
  const file = event.target.files[0];
  parseExcel(file, (data) => {
    displayProgram(data);
    saveToFirebase(data);
  });
});

function displayProgram(program) {
  const container = document.getElementById('program');
  container.innerHTML = '';
  const grouped = {};

  program.forEach(entry => {
    const key = `Неделя ${entry['Неделя']}, ${entry['День']}`;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(entry);
  });

  for (const [day, exercises] of Object.entries(grouped)) {
    const section = document.createElement('div');
    section.innerHTML = `<h2>${day}</h2>`;
    exercises.forEach(ex => {
      const exDiv = document.createElement('div');
      exDiv.innerHTML = `
        <strong>${ex['Упражнение']}</strong><br>
        Подходы: <input type="number" value="${ex['Подходы']}" /><br>
        Повторы: <input type="number" value="${ex['Повторы']}" /><br>
        Вес: <input type="number" value="${ex['Вес (кг)']}" step="0.5" /> кг<br>
        <label><input type="checkbox" /> Выполнено</label><hr>
      `;
      section.appendChild(exDiv);
    });
    container.appendChild(section);
  }
}

function saveToFirebase(data) {
  const userId = "demoUser"; // Здесь можно добавить авторизацию
  set(ref(db, 'programs/' + userId), data);
}